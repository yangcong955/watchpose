#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <AR/ar.h>
#include <AR/gsub.h>
#include <AR/video.h>

#include "engine.h"


#define             CPARA_NAME       "Cong/Camera_Cong.dat"
#define             PATT_NAME_1      "Cong/multimarker/hirobig.patt"

double              blurthreshold = 0.47; //a threshold to remove the blurred image
double              patt_width = 100.0;

ARHandle           *arHandle;
ARPattHandle       *arPattHandle;
AR3DHandle         *ar3DHandle;
ARGViewportHandle  *vp;
int                 xsize, ysize;
int                 flipMode = 0;
int                 patt_id;
int                 count = 0;
char                fps[256]; //to print on the video screen
char                errValue[256];
int                 distF = 0;
int                 contF = 0;
ARParamLT          *gCparamLT = NULL;

static ARMarkerInfo   *target = NULL; //for capturing the target maker
static ARdouble       pattRatio = (ARdouble)(AR_PATT_RATIO);

Engine             *ep; //for visulise the viewpoints in matlab
mxArray            *fulltranmatrix = NULL; //full transformation matrix, trans[3][4], c->matlab
mxArray            *ynplot = NULL; // whether to plot
//mxArray            *imagename = NULL; //image name to matlab
mxArray            *blurlevel = NULL; // whether to plot

static void   init(int argc, char *argv[]);
static void   cleanup(void);
static void   mainLoop(void);
static void   draw( ARdouble trans[3][4] );
static void savetrans(int mynumber, ARdouble trans[3][4], int makerid); //This function is used to save the transformation matrix
//static double * viewpointcal(ARdouble trans[3][4]); //This function is used to calculate the viewpoint
static void get_cpara(ARdouble world[4][2], ARdouble vertex[4][2], ARdouble para[3][3]); //for generate the world location
static int getPatternVerticesFromMarkerVertices(const ARdouble vertex[4][2], ARdouble patternVertex[4][2]); //for generating the maker vertex location
static void savemaklocation(int mynumber, ARdouble markerinside[4][2], ARdouble markeroutside[4][2], int makerid); //for print the marker info into txt file
static void savetempimage(ARUint8 *mydata); //This function is used to save captured frame into a temp jpg for blur checking
static void saveimg(int mynumber, int makerid);  //if the image is  not blurred, just change the temp name into real name

int main(int argc, char *argv[])
{
	glutInit(&argc, argv); //for opengl initialize
    init(argc, argv); //for ARToolKit initialisation, setup camera and load maker

	/*For calling matlab function*/
	if (!(ep = engOpen(NULL))) {
		MessageBox((HWND)NULL, (LPSTR)"Can't start MATLAB engine", (LPSTR) "SingleMakerTrack.c", MB_OK);
		exit(-1);
	}
	fulltranmatrix = mxCreateDoubleMatrix(3, 4, mxREAL); //For store the full transformation matrix
	engEvalString(ep, "[x, y, z] = sphere;"); //for plot a ball in matlab
	engEvalString(ep, "cd c:/dev/ARToolKit5/bin/Cong/matlab;"); //for plot a ball in matlab
	//engEvalString(ep, "figure;hSurface = surf(x+10, y+10, z+10,'FaceColor', 'none');"); //for plot a ball in matlab
	engEvalString(ep, "ballradius = 10;"); //define the radius of the ball
	engEvalString(ep, "ballcenter = [10,10,10];"); //define the center of the ball
	engEvalString(ep, "subballradius = 0.5;"); //define the small maker ball radius
	engEvalString(ep, "plotedpointlist = zeros(1,3);"); //define and initialize the ploted point list
	engEvalString(ep, "allowdis = 1.0;"); //density of the view point

	//engEvalString(ep, "figure;hSurface = surf((ballradius*x+ballcenter(1)), (ballradius*y+ballcenter(2)), (ballradius*z+ballcenter(3)),'FaceColor', 'none','EdgeColor',[0.5 0.5 0.5]);"); //for plot a ball in matlab
	engEvalString(ep, "figure;hSurface = surf((ballradius*x+ballcenter(1)), (ballradius*y+ballcenter(2)), (ballradius*z+ballcenter(3)),'FaceColor', [0.5 0.5 0.5]);"); //for plot a ball in matlab
	engEvalString(ep, "hold on;");
	engEvalString(ep, "plot3([ballcenter(1), ballcenter(1) + ballradius + 8], [ballcenter(2), ballcenter(2)], [ballcenter(3), ballcenter(3)], '-r', 'Linewidth', 1);");
	engEvalString(ep, "plot3([ballcenter(1), ballcenter(1)], [ballcenter(2), ballcenter(2) + ballradius + 8], [ballcenter(3), ballcenter(3)], '-g', 'Linewidth', 1);");
	engEvalString(ep, "plot3([ballcenter(1), ballcenter(1)], [ballcenter(2), ballcenter(2)], [ballcenter(3), ballcenter(3) + ballradius + 8], '-b', 'Linewidth', 1);");
	//engEvalString(ep, "mesh(0.3*x + ballcenter(1), 0.3*y + ballcenter(2), 0.3*z + ballcenter(3), ones(21, 21));");
	engEvalString(ep, "axis equal;"); 
	engEvalString(ep, "axis off;");
	engEvalString(ep, "previewpoint = [0,0,0];");
	//imagename = mxCreateDoubleMatrix(1, 2, mxREAL);


	//start the mainloop
    argSetDispFunc(mainLoop, 1);
	count = 0;
    fps[0] = '\0';
	arUtilTimerReset(); //reset the timer
    argMainLoop();

	//for clean memory and close matlab
	mxDestroyArray(fulltranmatrix);
	//mxDestroyArray(imagename);
	engClose(ep);
	return (0);
}

//For initilisation, set up camera and maker
static void init(int argc, char *argv[])
{
	ARParam         cparam;
	ARGViewport     viewport;
	char            vconf[512];
	AR_PIXEL_FORMAT pixFormat;
	ARUint32        id0, id1;
	int             i;

	if (argc == 1) vconf[0] = '\0';
	else {
		strcpy(vconf, argv[1]);
		for (i = 2; i < argc; i++) { strcat(vconf, " "); strcat(vconf, argv[i]); }
	}

	/* open the video path, if we don't find it, then using the default parameters */
	ARLOGi("Using video configuration '%s'.\n", vconf);

	if (arVideoOpen(vconf) < 0) exit(0); //open the video path

	if (arVideoGetSize(&xsize, &ysize) < 0) exit(0); //Find the size of the window
	ARLOGi("Image size (x,y) = (%d,%d)\n", xsize, ysize);

	if ((pixFormat = arVideoGetPixelFormat()) < 0) exit(0); //Get the format in which the camera is returning pixels.

	if (arVideoGetId(&id0, &id1) == 0) {
		ARLOGi("Camera ID = (%08x, %08x)\n", id1, id0);
		//sprintf(vconf, VPARA_NAME, id1, id0);
		if (arVideoLoadParam(vconf) < 0) {
			ARLOGe("No camera setting data!!\n");
		}
	}

	/* set the initial camera parameters */
	//Load the camera parameters, resize for the window and init.
	//Once the camera parameters are loaded, we adjust them to match 
	//the actual video image size being supplied by the video library, 
	//and then initialize a few necessary ARToolKit structures that 
	//depend on the camera parameters:

	if (arParamLoad(CPARA_NAME, 1, &cparam) < 0) {
		ARLOGe("Camera parameter load error !!\n");
		exit(0);
	}
	arParamChangeSize(&cparam, xsize, ysize, &cparam);
	ARLOG("*** Camera Parameter ***\n");
	arParamDisp(&cparam);


	//We complete our setupCamera by setting up some defaults related to the 
	//tracking portion of ARToolKit. These include debug mode, the labelling 
	//threshold, and the structure used to hold positions of detected patterns. 
	//Finally, we start the video library capturing frames, since we will soon 
	//be ready to process them.
	if ((gCparamLT = arParamLTCreate(&cparam, AR_PARAM_LT_DEFAULT_OFFSET)) == NULL) {
		ARLOGe("Error: arParamLTCreate.\n");
		exit(-1);
	}

	if ((arHandle = arCreateHandle(gCparamLT)) == NULL) {
		ARLOGe("Error: arCreateHandle.\n");
		exit(0);
	}
	if (arSetPixelFormat(arHandle, pixFormat) < 0) {
		ARLOGe("Error: arSetPixelFormat.\n");
		exit(0);
	}

	if ((ar3DHandle = ar3DCreateHandle(&cparam)) == NULL) {
		ARLOGe("Error: ar3DCreateHandle.\n");
		exit(0);
	}

	if ((arPattHandle = arPattCreateHandle()) == NULL) {
		ARLOGe("Error: arPattCreateHandle.\n");
		exit(0);
	}

	/*The second major part of ARToolKit setup is to load pattern files for 
	 *each of the patterns we wish to detect. In simpleLite, we will only track 
	 *one pattern, the basic �Hiro� pattern. setupMarker creates a list of patterns 
	 *for ARToolKit to track, and loads the Hiro pattern into it. Loading multiple 
	 *patterns can be seen in the simpleVRML example, and is covered in a later 
	 *chapter of the documentation.
	*/
	//load pattern
	if ((patt_id = arPattLoad(arPattHandle, PATT_NAME_1)) < 0) {
		ARLOGe("pattern A load error !!\n");
		exit(0);
	}
	arPattAttach(arHandle, arPattHandle);
	printf("Pattern ID = %f\n", patt_id);

	/* open the graphics window */
	/*
	int winSizeX, winSizeY;
	argCreateFullWindow();
	argGetScreenSize( &winSizeX, &winSizeY );
	viewport.sx = 0;
	viewport.sy = 0;
	viewport.xsize = winSizeX;
	viewport.ysize = winSizeY;
	*/
	arSetPattRatio(arHandle, (ARdouble)pattRatio);
	viewport.sx = 0;
	viewport.sy = 0;
	viewport.xsize = xsize;
	viewport.ysize = ysize;
	if ((vp = argCreateViewport(&viewport)) == NULL) exit(0);
	argViewportSetCparam(vp, &cparam);
	argViewportSetPixFormat(vp, pixFormat);
	//argViewportSetDispMethod( vp, AR_GL_DISP_METHOD_GL_DRAW_PIXELS );
	argViewportSetDistortionMode(vp, AR_GL_DISTORTION_COMPENSATE_DISABLE);

	if (arVideoCapStart() != 0) {
		ARLOGe("video capture start error !!\n");
		exit(0);
	}
}

static int imageNumber = 0; //for saving image and pattern
static int detectedid = 0; //to show the deteckted maker id
static int plotornot = 0; //whether should be plot and save
static int saveimagecount = 1; //for naming images to be saved
static double blur = 0; //to show how much blur level [0, 1]
static void mainLoop(void)
{
    static int      contF2 = 0;
    static ARdouble patt_trans[3][4];
    static ARUint8 *dataPtr = NULL;
    ARMarkerInfo   *markerInfo; //Maker information, a structure: area, id, direction, selfconfi, center point, boderinfo, peak axis
    int             markerNum; //number of the maker, here we only have 1
    ARdouble        err;
    int             imageProcMode;
    int             debugMode;
    int             j, k;
	ARdouble        patternVertex[4][2]; //for saving the pattern vertex

	target = NULL;

    /* grab a video frame */
    if( (dataPtr = (ARUint8 *)arVideoGetImage()) == NULL ) {
        arUtilSleep(2);
        return;
    }

    argDrawMode2D(vp);
    arGetDebugMode( arHandle, &debugMode ); //findout whether ARToolKit debug mode is enabled
    if( debugMode == 0 ) {
		/*dataPtr is the image target that we want to save, but first 
		we need to ensure that each image contains the correct maker*/
        argDrawImage( dataPtr ); 
		//sprintf(fps, "IE-Track: Draw Image000000");
    }
    else {
        arGetImageProcMode(arHandle, &imageProcMode);
        if( imageProcMode == AR_IMAGE_PROC_FRAME_IMAGE ) {
            argDrawImage( arHandle->labelInfo.bwImage );
			sprintf(fps, "IE-Track: Draw Image111111");
        }
        else {
            argDrawImageHalf( arHandle->labelInfo.bwImage );
			sprintf(fps, "IE-Track: Draw Image222222");
        }
    }

    /* detect the markers in the video frame */
    if( arDetectMarker(arHandle, dataPtr) < 0 ) {
		//If the detection can not be properly run, then exit the loop
        cleanup();
        exit(0);
    }

	//every 60 rounds, we reset the timer
    if( count % 60 == 0 ) {
        //sprintf(fps, "%f[fps]", 60.0/arUtilTimer());
        arUtilTimerReset(); //reset the timer
    }
    count++;

	//To get the number of detected maker
    markerNum = arGetMarkerNum( arHandle );
	sprintf(fps, "Detected Maker Number: %d", markerNum);
	//Here to show the fps on screen
	glColor3f(0.0f, 1.0f, 0.0f);
	argDrawStringsByIdealPos(fps, 20, ysize - 30);

	//If there is no maker detected, just finish this loop and start the next one
    if( markerNum == 0 ) {
        argSwapBuffers();
        return;
    }

    /* check for object visibility, makers are detected */
    markerInfo =  arGetMarker( arHandle ); 
    k = -1;

	//here is to check whether the maker is detected
    for( j = 0; j < markerNum; j++ ) {
        ///////ARLOG("ID=%d, CF = %f\n", markerInfo[j].id, markerInfo[j].cf);
        if( patt_id == markerInfo[j].id ) {
            if( k == -1 ) {
				if (markerInfo[j].cf >= 0.8) {
					k = j;
					detectedid = markerInfo[j].id;
					target = &(markerInfo[j]);
				}
			}
			else if (markerInfo[j].cf > markerInfo[k].cf) {
				k = j;
				detectedid = markerInfo[j].id;
				target = &(markerInfo[j]);
			}
        }
    }

	//If the detected maker is not the maker we want, just return. Otherwise, continue
    if( k == -1 ) {
        contF2 = 0;
        argSwapBuffers();
        return;
    }

    if( contF && contF2 ) {
        err = arGetTransMatSquareCont(ar3DHandle, &(markerInfo[k]), patt_trans, patt_width, patt_trans);
    }
    else {
        err = arGetTransMatSquare(ar3DHandle, &(markerInfo[k]), patt_width, patt_trans);
    }
    sprintf(errValue, "err = %f", err);

	/***Here we start to get the maker location and save it into file***/
	getPatternVerticesFromMarkerVertices((const ARdouble(*)[2])target->vertex, patternVertex);


	/****here we calculate and plot the viewpoint******/
	memcpy((char *)mxGetPr(fulltranmatrix), (char *)patt_trans, 3 * 4 * sizeof(double)); //copy values
	engPutVariable(ep, "fulltranmatrix", fulltranmatrix);
	engEvalString(ep, "rotMax = zeros(3,3);"); //define the rotation matrix
	engEvalString(ep, "TraMax = zeros(3,1);"); //define the rotation matrix
	//set values to rotation and transmation matrix
	engEvalString(ep, "rotMax(1,1) = fulltranmatrix(1,1);rotMax(1,2) = fulltranmatrix(2,1);rotMax(1,3) = fulltranmatrix(3,1);");
	engEvalString(ep, "rotMax(2,1) = fulltranmatrix(2,2);rotMax(2,2) = fulltranmatrix(3,2);rotMax(2,3) = fulltranmatrix(1,3);");
	engEvalString(ep, "rotMax(3,1) = fulltranmatrix(3,3);rotMax(3,2) = fulltranmatrix(1,4);rotMax(3,3) = fulltranmatrix(2,4);");
	engEvalString(ep, "TraMax(1,1) = fulltranmatrix(1,2);TraMax(2,1) = fulltranmatrix(2,3);TraMax(3,1) = fulltranmatrix(3,4);");
	
	//calculate the viewpoint by -R*t
	engEvalString(ep, "ViewPoint = -rotMax*TraMax;ViewPoint = ViewPoint';");
	engEvalString(ep, "title(['Total Count:',num2str(size(plotedpointlist,1))]);");
	engEvalString(ep, "view(ViewPoint);");
	engEvalString(ep, "axis equal;");
	//engEvalString(ep, "if norm(ViewPoint - previewpoint) > 88 rotate(hSurface, ViewPoint, 25); end");
	engEvalString(ep, "previewpoint = ViewPoint;");
	/****Matlab View Point End******/

	//Here we start to save image and pattern
	imageNumber++;
	if (imageNumber % 10 == 0) {

		//patt_trans[0][0] = 1;
		//patt_trans[0][1] = 2;
		//patt_trans[0][2] = 3;
		//patt_trans[0][3] = 4;
		//patt_trans[1][0] = 5;
		//patt_trans[1][1] = 6;
		//patt_trans[1][2] = 7;
		//patt_trans[1][3] = 8;
		//patt_trans[2][0] = 9;
		//patt_trans[2][1] = 10;
		//patt_trans[2][2] = 11;
		//patt_trans[2][3] = 12;

		//start to save and plot the viewpoint
		engEvalString(ep, "[plotview] = plotpoint(ViewPoint, ballcenter, ballradius);");
		engEvalString(ep, "[ynplot] = checklist(plotview, plotedpointlist, allowdis);");
		ynplot = engGetVariable(ep, "ynplot");
		plotornot = (int)mxGetScalar(ynplot);
		//printf("%d\n", plotornot);
		//if this view point has not been marked, mark, plot and save it
		if (plotornot == 1) {
			savetempimage(dataPtr); //here we save a temp image for blur evaluation
			
			//Here we check whether the saved image is blurred
			engEvalString(ep, "im = imread('c:/dev/ARToolKit5/bin/Cong/image/temp.jpg');");
			//engEvalString(ep, "blurlevel = blurMetric(im);");
			//engEvalString(ep, "clear im;");
			//blurlevel = engGetVariable(ep, "blurlevel");
			//blur = (double)mxGetScalar(blurlevel); //get the blur level from matlab
			//if (blur <= blurthreshold) {
				saveimg(saveimagecount, detectedid); //change the temp image name into real one
				savetrans(saveimagecount, patt_trans, detectedid); //save the rotation+translation matrix
				savemaklocation(saveimagecount, patternVertex, target->vertex, detectedid); //save the marker location

				//update the point list
				engEvalString(ep, "plotedpointlist(size(plotedpointlist,1)+1,1:3)=plotview;");
				//plot the viewpoint
				engEvalString(ep, "surf((subballradius*x + plotview(1)), (subballradius*y + plotview(2)), (subballradius*z + plotview(3)), 'FaceColor', 'r', 'EdgeColor', 'r');");
				saveimagecount = saveimagecount + 1;
				ARLOG("Marker ID=%d, ", detectedid);
			//}
		}
	}

	//if counter is too big, set to zero
	if (imageNumber >= 10000){
		imageNumber = 0;
	}

    glColor3f(0.0f, 1.0f, 0.0f);
    argDrawStringsByIdealPos(fps, 20, ysize-30);
    argDrawStringsByIdealPos(errValue, 10, ysize-60);
    //ARLOG("err = %f\n", err);

    contF2 = 1;
    draw(patt_trans);
    argSwapBuffers();
}

/* cleanup function called when program exits */
static void cleanup(void)
{
    arVideoCapStop();
    argCleanup();
	arPattDetach(arHandle);
	arPattDeleteHandle(arPattHandle);
	ar3DDeleteHandle(&ar3DHandle);
	arDeleteHandle(arHandle);
    arParamLTFree(&gCparamLT);
    arVideoClose();
}

static void draw(ARdouble trans[3][4])
{
    ARdouble  gl_para[16];
    GLfloat   mat_diffuse[]     = {0.0f, 0.0f, 1.0f, 0.0f};
    GLfloat   mat_flash[]       = {1.0f, 1.0f, 1.0f, 0.0f};
    GLfloat   mat_flash_shiny[] = {50.0f};
    GLfloat   light_position[]  = {100.0f,-200.0f,200.0f,0.0f};
    GLfloat   light_ambi[]      = {0.1f, 0.1f, 0.1f, 0.0f};
    GLfloat   light_color[]     = {1.0f, 1.0f, 1.0f, 0.0f};
    
    argDrawMode3D(vp);
    glClearDepth( 1.0 );
    glClear(GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    
    /* load the camera transformation matrix */
    argConvGlpara(trans, gl_para);
    glMatrixMode(GL_MODELVIEW);
#ifdef ARDOUBLE_IS_FLOAT
    glLoadMatrixf( gl_para );
#else
    glLoadMatrixd( gl_para );
#endif

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, 1);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    glLightfv(GL_LIGHT0, GL_AMBIENT,  light_ambi);
    glLightfv(GL_LIGHT0, GL_DIFFUSE,  light_color);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_color);
    glMaterialfv(GL_FRONT, GL_SPECULAR,  mat_flash);
    glMaterialfv(GL_FRONT, GL_SHININESS, mat_flash_shiny);	
    glMaterialfv(GL_FRONT, GL_DIFFUSE,   mat_diffuse);
    glMaterialfv(GL_FRONT, GL_AMBIENT,   mat_diffuse);

#if 1
    glTranslatef( 0.0f, 0.0f, 40.0f );
    glutSolidCube(80.0);
#else
    glTranslatef( 0.0f, 0.0f, 20.0f );
    glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
    glutSolidTeapot(40.0);
#endif
    glDisable(GL_LIGHT0);
    glDisable( GL_LIGHTING );

    glDisable( GL_DEPTH_TEST );
}

static void savetempimage(ARUint8 *mydata) 
{
	//This function is used to transfer the captured frame into jpg and save it
	char myname[20];
	strcpy(myname, "Cong/image/temp.jpg");
	if (arVideoSaveImageJPEG(arHandle->xsize, arHandle->ysize, arHandle->arPixelFormat, mydata, myname, 75, 0) < 0) {
		ARLOGe("Error saving video image.\n");
		return;
	}
}

static void saveimg(int mynumber, int makerid)
{
	//In this function, we accutally only change the name of the saved 
	//temp.jpg. In such a case, we don't have to save the image again.
	int ret;
	char myname[50];
	char tempnum[20];
	strcpy(myname, "Cong/image/img_");
	_itoa(makerid, tempnum, 10); //transfer a int number into string. 10 means decimalism
	strcat(myname, tempnum);
	strcat(myname, "_");
	_itoa(mynumber, tempnum, 10); //transfer a int number into string. 10 means decimalism
	strcat(myname, tempnum);
	strcat(myname, ".jpg");
	ret = rename("Cong/image/temp.jpg", myname); //rename the temp.jpg to img_markerid_imgnumber.jpg
	if (ret == 0)
	{
		printf("%s\n", myname);
	}
	else
	{
		printf("Error: unable to rename the file");
		return;
	}
	

	//double tempnumber[1][2] = {makerid,mynumber};

	//here we put the image number value to matlab
	//memcpy((void *)mxGetPr(imagename), (void *)tempnumber, sizeof(double) * 1 * 2);
	//memcpy((char *)mxGetPr(imagename), (char *)tempnumber, 1 * 1 * sizeof(double)); //copy values
	//engPutVariable(ep, "imagename", imagename);
	//engEvalString(ep, "imagename = ['c:/dev/ARToolKit5/bin/Cong/image/img_',num2str(imagename(1)),'_',num2str(imagename(2)),'.jpg'];");
}

static void savetrans(int mynumber, ARdouble trans[3][4], int makerid) {
	/*About the transformation matrix trans[3][4]
	If we consider the transformation matrix of individual markers, 
	the first three columns are a rotation matrix which represent 
	the rotation of the marker with respect to the origin of the multimarker 
	set. This is the standard 3�3 rotation matrix familiar in computer graphics 
	or linear algebra. The fourth column is the offset from the origin 
	of the multimarker set to the origin (the centre) of this the individual marker.	
	*/

	int i, j;
	char myname[50];
	char tempnum[20];
	strcpy(myname, "Cong/image/tran_");
	_itoa(makerid, tempnum, 10); //transfer a int number into string. 10 means decimalism
	strcat(myname, tempnum);
	strcat(myname, "_");
	_itoa(mynumber, tempnum, 10); //transfer a int number into string. 10 means decimalism
	strcat(myname, tempnum);
	strcat(myname, ".txt");

	FILE *handlewrite = fopen(myname, "w");
	for (i = 0; i < 3; i++){
		for (j = 0; j < 4; j++) {
			//printf("yangcong------%f  ", trans[i][j]);
			fprintf(handlewrite, "%f ", trans[i][j]);
		}
		fprintf(handlewrite, "\n");
	}

	fclose(handlewrite);
}

static void savemaklocation(int mynumber, ARdouble markerinside[4][2], ARdouble markeroutside[4][2], int makerid) {
	/*In this function, we will save the makers location into file. markerinside[4][2] means the four 
	vertex inside the black area of marker. markeroutside means the four vertex outside the marker.
	*/

	int i, j;
	char myname[50];
	char tempnum[20];
	strcpy(myname, "Cong/image/makloca_");
	_itoa(makerid, tempnum, 10); //transfer a int number into string. 10 means decimalism
	strcat(myname, tempnum);
	strcat(myname, "_");
	_itoa(mynumber, tempnum, 10); //transfer a int number into string. 10 means decimalism
	strcat(myname, tempnum);
	strcat(myname, ".txt");

	FILE *handlewrite = fopen(myname, "w");
	for (i = 0; i < 4; i++){
		for (j = 0; j < 2; j++) {
			//printf("yangcong------%f  ", trans[i][j]);
			fprintf(handlewrite, "%f ", markerinside[i][j]);
		}
		fprintf(handlewrite, "\n");
	}
	for (i = 0; i < 4; i++){
		for (j = 0; j < 2; j++) {
			//printf("yangcong------%f  ", trans[i][j]);
			fprintf(handlewrite, "%f ", markeroutside[i][j]);
		}
		fprintf(handlewrite, "\n");
	}
	fclose(handlewrite);
}

//
//static double * viewpointcal(ARdouble trans[3][4]) {
//	/*In this function, we try to calculate the viewpoint from the 
//	transformation matrix trans[3][4]. The output is [x,y,z] About 
//	the transformation matrix trans[3][4]. If we consider the transformation 
//	matrix of individual markers, the first three columns are a rotation matrix 
//	which represent	the rotation of the marker with respect to the origin of 
//	the multimarker set. This is the standard 3�3 rotation matrix familiar 
//	in computer graphics or linear algebra. The fourth column is the offset 
//	from the origin of the multimarker set to the origin (the centre) of this 
//	the individual marker.
//	*/
//	int i, j;
//
//	printf("Product of matrix Original:\n");
//	for (i = 0; i < 3; i++){
//		for (j = 0; j < 4; j++){
//			printf("%f\t", trans[i][j]);
//		}
//		printf("\n");
//	}
//
//
//	int mycountro = 0;
//	int mycounttr = 0;
//	double RoM[3][3], TrM[3];
//	// First step: Generate the rotation matrix and the 
//	for (i = 0; i < 3; i++) {
//		mycountro = 0;
//		for (j = 0; j < 4; j++) {
//			if (j < 3){
//				RoM[i][mycountro] = -1 * trans[i][j];
//				mycountro = mycountro + 1;
//			}
//			else{
//				TrM[mycounttr] = trans[i][j];
//				mycounttr = mycounttr + 1;
//			}
//		}
//	}
//
//	printf("Product of matrix A:\n");
//	for (i = 0; i < 3; i++){
//		for (j = 0; j < 3; j++){
//			printf("%f\t", RoM[i][j]);
//		}
//		printf("\n");
//	}
//
//	printf("Product of matrix B:\n");
//	for (i = 0; i < 3; i++) {
//		printf("%f\t", TrM[i]);
//	}
//	printf("\n");
//
//	double ViewPoint[3];
//	//second step: calculate the viewpoint location by multiplication of two matrix
//	//we need to ensure the column number of matrix A = the row number of matrix B
//	// RoM * TrM: [3][3] * [3][1] = [3, 1]
//
//	//m, n the number of rows and columns of first matrix
//	//p, q the number of rows and columns of second matrix
//	int c, d, k;
//	int m = 3; int n = 3; int p = 3; int q = 1; 
//	double sum = 0;
//	for (c = 0; c < m; c++) {
//		for (d = 0; d < q; d++) {
//			for (k = 0; k < p; k++) {
//				sum = sum + RoM[c][k] * TrM[k];
//			}
//			ViewPoint[c] = sum;
//			sum = 0;
//		}
//	}
//
//	return ViewPoint;
//}

static void get_cpara(ARdouble world[4][2], ARdouble vertex[4][2], ARdouble para[3][3])
{
	ARMat   *a, *b, *c;
	int     i;

	a = arMatrixAlloc(8, 8);
	b = arMatrixAlloc(8, 1);
	c = arMatrixAlloc(8, 1);
	for (i = 0; i < 4; i++) {
		a->m[i * 16 + 0] = world[i][0];
		a->m[i * 16 + 1] = world[i][1];
		a->m[i * 16 + 2] = 1.0;
		a->m[i * 16 + 3] = 0.0;
		a->m[i * 16 + 4] = 0.0;
		a->m[i * 16 + 5] = 0.0;
		a->m[i * 16 + 6] = -world[i][0] * vertex[i][0];
		a->m[i * 16 + 7] = -world[i][1] * vertex[i][0];
		a->m[i * 16 + 8] = 0.0;
		a->m[i * 16 + 9] = 0.0;
		a->m[i * 16 + 10] = 0.0;
		a->m[i * 16 + 11] = world[i][0];
		a->m[i * 16 + 12] = world[i][1];
		a->m[i * 16 + 13] = 1.0;
		a->m[i * 16 + 14] = -world[i][0] * vertex[i][1];
		a->m[i * 16 + 15] = -world[i][1] * vertex[i][1];
		b->m[i * 2 + 0] = vertex[i][0];
		b->m[i * 2 + 1] = vertex[i][1];
	}
	arMatrixSelfInv(a);
	arMatrixMul(c, a, b);
	for (i = 0; i < 2; i++) {
		para[i][0] = c->m[i * 3 + 0];
		para[i][1] = c->m[i * 3 + 1];
		para[i][2] = c->m[i * 3 + 2];
	}
	para[2][0] = c->m[2 * 3 + 0];
	para[2][1] = c->m[2 * 3 + 1];
	para[2][2] = 1.0;
	arMatrixFree(a);
	arMatrixFree(b);
	arMatrixFree(c);
}

static int getPatternVerticesFromMarkerVertices(const ARdouble vertex[4][2], ARdouble patternVertex[4][2])
{
	int i;
	ARdouble    world[4][2];
	ARdouble    local[4][2];
	ARdouble    para[3][3];
	ARdouble    d, xw, yw;
	ARdouble    pattRatio1, pattRatio2;

	world[0][0] = 100.0;
	world[0][1] = 100.0;
	world[1][0] = 100.0 + 10.0;
	world[1][1] = 100.0;
	world[2][0] = 100.0 + 10.0;
	world[2][1] = 100.0 + 10.0;
	world[3][0] = 100.0;
	world[3][1] = 100.0 + 10.0;
	for (i = 0; i < 4; i++) {
		local[i][0] = vertex[i][0];
		local[i][1] = vertex[i][1];
	}
	get_cpara(world, local, para);

	pattRatio1 = (1.0 - pattRatio) / 2.0 * 10.0; // borderSize * 10.0
	pattRatio2 = 10.0*pattRatio;

	world[0][0] = 100.0 + pattRatio1;
	world[0][1] = 100.0 + pattRatio1;
	world[1][0] = 100.0 + pattRatio1 + pattRatio2;
	world[1][1] = 100.0 + pattRatio1;
	world[2][0] = 100.0 + pattRatio1 + pattRatio2;
	world[2][1] = 100.0 + pattRatio1 + pattRatio2;
	world[3][0] = 100.0 + pattRatio1;
	world[3][1] = 100.0 + pattRatio1 + pattRatio2;

	for (i = 0; i < 4; i++) {
		yw = world[i][1];
		xw = world[i][0];
		d = para[2][0] * xw + para[2][1] * yw + para[2][2];
		if (d == 0) return -1;
		patternVertex[i][0] = (para[0][0] * xw + para[0][1] * yw + para[0][2]) / d;
		patternVertex[i][1] = (para[1][0] * xw + para[1][1] * yw + para[1][2]) / d;
	}
	return (0);
}