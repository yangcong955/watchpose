//#include <windows.h>
//#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>
//#include <GL/gl.h>
//#include <GL/glut.h>
//#include <AR/ar.h>
//#include <AR/gsub.h>
//#include <AR/video.h>
//#include <cv.h>
//#include <highgui.h>
//#include <math.h>
//typedef unsigned int uint8;
//
//
//#define             CPARA_NAME       "Cong/Camera_Cong.dat"
////#define             PATT_NAME_1      "Cong/myF.patt"
//#define             PATT_NAME_1      "Cong/multimarker/hirobig.patt"
//
////const char *sDir = "C:\\CongYang\\Work France\\experiments\\TrainingSamples\\dataset\\withmarker\\experiment2\\object1_enriched\\big\\888\\";
//const char *sDir = "C:\\CongYang\\Work France\\experiments\\TrainingSamples\\dataset\\withmarker\\experiment2\\compare2_enriched\\39\\";
//
//double              patt_width = 100.0;
//int globalcount = 19394;
//
//
//IplImage* img = 0;
//int height, width, step, channels;
//
//ARHandle           *arHandle;
//ARPattHandle       *arPattHandle;
//AR3DHandle         *ar3DHandle;
//ARGViewportHandle  *vp;
//int                 xsize, ysize;
//int                 flipMode = 0;
//int                 patt_id;
//int                 count = 0;
//char                fps[256]; //to print on the video screen
//char                errValue[256];
//int                 distF = 0;
//int                 contF = 0;
//ARParamLT          *gCparamLT = NULL;
//
//static ARMarkerInfo   *target = NULL; //for capturing the target maker
//static ARdouble       pattRatio = (ARdouble)(AR_PATT_RATIO);
//
//
//static void   init(int argc, char *argv[]);
//static void   cleanup(void);
//static void   mainLoop(void);
//static void savetrans(int mynumber, ARdouble trans[3][4], int makerid); //This function is used to save the transformation matrix
////static double * viewpointcal(ARdouble trans[3][4]); //This function is used to calculate the viewpoint
//static void get_cpara(ARdouble world[4][2], ARdouble vertex[4][2], ARdouble para[3][3]); //for generate the world location
//static int getPatternVerticesFromMarkerVertices(const ARdouble vertex[4][2], ARdouble patternVertex[4][2]); //for generating the maker vertex location
//static void savemaklocation(int mynumber, ARdouble markerinside[4][2], ARdouble markeroutside[4][2], int makerid); //for print the marker info into txt file
//static void savetempimage(ARUint8 *mydata); //This function is used to save captured frame into a temp jpg for blur checking
//static void saveimg(int mynumber, int makerid);  //if the image is  not blurred, just change the temp name into real name
//
//int main(int argc, char *argv[])
//{
//	glutInit(&argc, argv); //for opengl initialize
//    init(argc, argv); //for ARToolKit initialisation, setup camera and load maker
//
//	//img = cvLoadImage("C://CongYang//Work France//experiments//TrainingSamples//dataset//testing1//original//object1//4.jpg", 1);
//	//if (!img){
//	//	printf("Could not load image file: %s\n", argv[1]);
//	//	exit(0);
//	//}
//
//	////start the mainloop
//	//mainLoop();
//
//	WIN32_FIND_DATA fdFile;
//	HANDLE hFind = NULL;
//	char sPath[2048];
//	//Specify a file mask. *.* = We want everything!
//	sprintf(sPath, "%s\\*.*", sDir);
//	if ((hFind = FindFirstFile(sPath, &fdFile)) == INVALID_HANDLE_VALUE)
//	{
//		printf("Path not found: [%s]\n", sDir);
//		return FALSE;
//	}
//
//	do
//	{
//		//Find first file will always return "."
//		//    and ".." as the first two directories.
//		if (strcmp(fdFile.cFileName, ".") != 0 && strcmp(fdFile.cFileName, "..") != 0)
//		{
//			//Build up our file path using the passed in
//			//  [sDir] and the file/foldername we just found:
//			sprintf(sPath, "%s\%s", sDir, fdFile.cFileName);
//
//			//Is the entity a File or Folder?
//			if (fdFile.dwFileAttributes &FILE_ATTRIBUTE_DIRECTORY)
//			{
//				printf("Directory: %s\n", sPath);
//				//ListDirectoryContents(sPath); //Recursion, I love it!
//			}
//			else{
//				printf("File: %s\n", sPath);
//				img = cvLoadImage(sPath, 1);
//				if (!img){
//					printf("Could not load image file: %s\n", argv[1]);
//					exit(0);
//				}
//				//cvNamedWindow("Image view", 1);
//				//cvShowImage("Image view", img);
//				//cvWaitKey(0);
//				//cvDestroyWindow("Image view");
//				mainLoop();
//			}
//		}
//	} while (FindNextFile(hFind, &fdFile)); //Find the next file.
//
//	FindClose(hFind); //Always, Always, clean things up!
//
//	printf("hello world");
//	return (0);
//}
//
////static BOOLEAN ListDirectoryContents(const char *sDir)
////{
////	WIN32_FIND_DATA fdFile;
////	HANDLE hFind = NULL;
////
////	char sPath[2048];
////
////	//Specify a file mask. *.* = We want everything!
////	sprintf(sPath, "%s\\*.*", sDir);
////
////	if ((hFind = FindFirstFile(sPath, &fdFile)) == INVALID_HANDLE_VALUE)
////	{
////		printf("Path not found: [%s]\n", sDir);
////		return FALSE;
////	}
////
////	do
////	{
////		//Find first file will always return "."
////		//    and ".." as the first two directories.
////		if (strcmp(fdFile.cFileName, ".") != 0
////			&& strcmp(fdFile.cFileName, "..") != 0)
////		{
////			//Build up our file path using the passed in
////			//  [sDir] and the file/foldername we just found:
////			sprintf(sPath, "%s\\%s", sDir, fdFile.cFileName);
////
////			//Is the entity a File or Folder?
////			if (fdFile.dwFileAttributes &FILE_ATTRIBUTE_DIRECTORY)
////			{
////				printf("Directory: %s\n", sPath);
////				ListDirectoryContents(sPath); //Recursion, I love it!
////			}
////			else{
////				printf("File: %s\n", sPath);
////			}
////		}
////	} while (FindNextFile(hFind, &fdFile)); //Find the next file.
////
////	FindClose(hFind); //Always, Always, clean things up!
////
////	return TRUE;
////}
//
//
////For initilisation, set up camera and maker
//static void init(int argc, char *argv[])
//{
//	ARParam         cparam;
//	ARGViewport     viewport;
//	char            vconf[512];
//	AR_PIXEL_FORMAT pixFormat;
//	ARUint32        id0, id1;
//	int             i;
//
//	if (argc == 1) vconf[0] = '\0';
//	else {
//		strcpy(vconf, argv[1]);
//		for (i = 2; i < argc; i++) { strcat(vconf, " "); strcat(vconf, argv[i]); }
//	}
//
//	/* open the video path, if we don't find it, then using the default parameters */
//	//ARLOGi("Using video configuration '%s'.\n", vconf);
//
//	if (arVideoOpen(vconf) < 0) exit(0); //open the video path
//
//	if (arVideoGetSize(&xsize, &ysize) < 0) exit(0); //Find the size of the window
//	ARLOGi("Image size (x,y) = (%d,%d)\n", xsize, ysize);
//
//	if ((pixFormat = arVideoGetPixelFormat()) < 0) exit(0); //Get the format in which the camera is returning pixels.
//
//	if (arVideoGetId(&id0, &id1) == 0) {
//		ARLOGi("Camera ID = (%08x, %08x)\n", id1, id0);
//		//sprintf(vconf, VPARA_NAME, id1, id0);
//		if (arVideoLoadParam(vconf) < 0) {
//			ARLOGe("No camera setting data!!\n");
//		}
//	}
//
//	/* set the initial camera parameters */
//	//Load the camera parameters, resize for the window and init.
//	//Once the camera parameters are loaded, we adjust them to match 
//	//the actual video image size being supplied by the video library, 
//	//and then initialize a few necessary ARToolKit structures that 
//	//depend on the camera parameters:
//
//	if (arParamLoad(CPARA_NAME, 1, &cparam) < 0) {
//		ARLOGe("Camera parameter load error !!\n");
//		exit(0);
//	}
//	arParamChangeSize(&cparam, xsize, ysize, &cparam);
//	ARLOG("*** Camera Parameter ***\n");
//	arParamDisp(&cparam);
//
//
//	//We complete our setupCamera by setting up some defaults related to the 
//	//tracking portion of ARToolKit. These include debug mode, the labelling 
//	//threshold, and the structure used to hold positions of detected patterns. 
//	//Finally, we start the video library capturing frames, since we will soon 
//	//be ready to process them.
//	if ((gCparamLT = arParamLTCreate(&cparam, AR_PARAM_LT_DEFAULT_OFFSET)) == NULL) {
//		ARLOGe("Error: arParamLTCreate.\n");
//		exit(-1);
//	}
//
//	if ((arHandle = arCreateHandle(gCparamLT)) == NULL) {
//		ARLOGe("Error: arCreateHandle.\n");
//		exit(0);
//	}
//	if (arSetPixelFormat(arHandle, pixFormat) < 0) {
//		ARLOGe("Error: arSetPixelFormat.\n");
//		exit(0);
//	}
//
//	if ((ar3DHandle = ar3DCreateHandle(&cparam)) == NULL) {
//		ARLOGe("Error: ar3DCreateHandle.\n");
//		exit(0);
//	}
//
//	if ((arPattHandle = arPattCreateHandle()) == NULL) {
//		ARLOGe("Error: arPattCreateHandle.\n");
//		exit(0);
//	}
//
//	/*The second major part of ARToolKit setup is to load pattern files for 
//	 *each of the patterns we wish to detect. In simpleLite, we will only track 
//	 *one pattern, the basic �Hiro� pattern. setupMarker creates a list of patterns 
//	 *for ARToolKit to track, and loads the Hiro pattern into it. Loading multiple 
//	 *patterns can be seen in the simpleVRML example, and is covered in a later 
//	 *chapter of the documentation.
//	*/
//	//load pattern
//	if ((patt_id = arPattLoad(arPattHandle, PATT_NAME_1)) < 0) {
//		ARLOGe("pattern A load error !!\n");
//		exit(0);
//	}
//	arPattAttach(arHandle, arPattHandle);
//	printf("Pattern ID = %f\n", patt_id);
//
//	/* open the graphics window */
//	/*
//	int winSizeX, winSizeY;
//	argCreateFullWindow();
//	argGetScreenSize( &winSizeX, &winSizeY );
//	viewport.sx = 0;
//	viewport.sy = 0;
//	viewport.xsize = winSizeX;
//	viewport.ysize = winSizeY;
//	*/
//	arSetPattRatio(arHandle, (ARdouble)pattRatio);
//	viewport.sx = 0;
//	viewport.sy = 0;
//	viewport.xsize = xsize;
//	viewport.ysize = ysize;
//	if ((vp = argCreateViewport(&viewport)) == NULL) exit(0);
//	argViewportSetCparam(vp, &cparam);
//	argViewportSetPixFormat(vp, pixFormat);
//	//argViewportSetDispMethod( vp, AR_GL_DISP_METHOD_GL_DRAW_PIXELS );
//	argViewportSetDistortionMode(vp, AR_GL_DISTORTION_COMPENSATE_DISABLE);
//
//	if (arVideoCapStart() != 0) {
//		ARLOGe("video capture start error !!\n");
//		exit(0);
//	}
//}
//
//static int detectedid = 0; //to show the deteckted maker id
//static void mainLoop(void)
//{
//    static int      contF2 = 0;
//    static ARdouble patt_trans[3][4];
//    //static ARUint8 *dataPtr = NULL;
//    ARMarkerInfo   *markerInfo; //Maker information, a structure: area, id, direction, selfconfi, center point, boderinfo, peak axis
//    int             markerNum; //number of the maker, here we only have 1
//    ARdouble        err;
//    int             imageProcMode;
//    int             debugMode;
//    int             j, k;
//	ARdouble        patternVertex[4][2]; //for saving the pattern vertex
//
//	target = NULL;
//
//    /* grab a video frame */
//    //if( (dataPtr = (ARUint8 *)arVideoGetImage()) == NULL ) {
//    //    arUtilSleep(2);
//    //    return;
//    //}
//
//
//	// get the image data
//	height = img->height;
//	width = img->width;
//	step = img->widthStep;
//	channels = img->nChannels;
//	//data = (uchar *)img->imageData;
//	printf("Processing a %dx%d image with %d channels\n", height, width, channels);
//
//	ARUint8* dataPtr = (ARUint8*)calloc(width * height * 3, sizeof(ARUint8));
//	int i = 0;
//	for (int y = 0; y < height; y++)
//	{
//		for (int x = 0; x < width; x++)
//		{
//			uint8 *blue = ((uchar *)(img->imageData + img->widthStep*y))[x*channels + 0];
//			uint8 *green = ((uchar *)(img->imageData + img->widthStep*y))[x*channels + 1];
//			uint8 *red = ((uchar *)(img->imageData + img->widthStep*y))[x*channels + 2];
//
//			//printf("My channels: %d%d%d\n", blue, green, red);
//
//			i = ((y * width) + x) * 3; // Figure out index in array
//			dataPtr[i] = blue;
//			dataPtr[i + 1] = green;
//			dataPtr[i + 2] = red;
//			//dataPtr[i + 3] = 0; // Alpha
//		}
//	}
//
//	// release the image
//	cvReleaseImage(&img);
//
//    argDrawMode2D(vp);
//    arGetDebugMode( arHandle, &debugMode ); //findout whether ARToolKit debug mode is enabled
//    if( debugMode == 0 ) {
//		/*dataPtr is the image target that we want to save, but first 
//		we need to ensure that each image contains the correct maker*/
//        argDrawImage( dataPtr ); 
//		//sprintf(fps, "IE-Track: Draw Image000000");
//    }
//    else {
//        arGetImageProcMode(arHandle, &imageProcMode);
//        if( imageProcMode == AR_IMAGE_PROC_FRAME_IMAGE ) {
//            argDrawImage( arHandle->labelInfo.bwImage );
//			sprintf(fps, "IE-Track: Draw Image111111");
//        }
//        else {
//            argDrawImageHalf( arHandle->labelInfo.bwImage );
//			sprintf(fps, "IE-Track: Draw Image222222");
//        }
//    }
//
//    /* detect the markers in the video frame */
//    if( arDetectMarker(arHandle, dataPtr) < 0 ) {
//		//If the detection can not be properly run, then exit the loop
//        cleanup();
//        exit(0);
//    }
//
//	//To get the number of detected maker
//    markerNum = arGetMarkerNum( arHandle );
//	sprintf(fps, "Detected Maker Number: %d", markerNum);
//	printf("Detected Maker Number: %d\n", markerNum);
//	//Here to show the fps on screen
//	glColor3f(0.0f, 1.0f, 0.0f);
//	argDrawStringsByIdealPos(fps, 20, ysize - 30);
//
//	//If there is no maker detected, just finish this loop and start the next one
//    if( markerNum == 0 ) {
//        argSwapBuffers();
//        return;
//    }
//
//    /* check for object visibility, makers are detected */
//    markerInfo =  arGetMarker( arHandle ); 
//    k = -1;
//
//	//here is to check whether the maker is detected
//    for( j = 0; j < markerNum; j++ ) {
//        ///////ARLOG("ID=%d, CF = %f\n", markerInfo[j].id, markerInfo[j].cf);
//        if( patt_id == markerInfo[j].id ) {
//            if( k == -1 ) {
//				if (markerInfo[j].cf >= 0.8) {
//					k = j;
//					detectedid = markerInfo[j].id;
//					target = &(markerInfo[j]);
//				}
//			}
//			else if (markerInfo[j].cf > markerInfo[k].cf) {
//				k = j;
//				detectedid = markerInfo[j].id;
//				target = &(markerInfo[j]);
//			}
//        }
//    }
//
//	//If the detected maker is not the maker we want, just return. Otherwise, continue
//    if( k == -1 ) {
//        contF2 = 0;
//        argSwapBuffers();
//        return;
//    }
//
//    if( contF && contF2 ) {
//        err = arGetTransMatSquareCont(ar3DHandle, &(markerInfo[k]), patt_trans, patt_width, patt_trans);
//    }
//    else {
//        err = arGetTransMatSquare(ar3DHandle, &(markerInfo[k]), patt_width, patt_trans);
//    }
//    sprintf(errValue, "err = %f", err);
//
//	/***Here we start to get the maker location and save it into file***/
//	getPatternVerticesFromMarkerVertices((const ARdouble(*)[2])target->vertex, patternVertex);
//
//	//Here we start to save image and pattern
//	int saveimagecount = globalcount;
//	savetempimage(dataPtr); //here we save a temp image for blur evaluation
//	saveimg(saveimagecount, detectedid); //change the temp image name into real one
//	savetrans(saveimagecount, patt_trans, detectedid); //save the rotation+translation matrix
//	savemaklocation(saveimagecount, patternVertex, target->vertex, detectedid); //save the marker location
//	globalcount = globalcount + 1;
//
//	//update the point list
//	//ARLOG("Marker ID=%d, ", detectedid);
//
//
//
//    //glColor3f(0.0f, 1.0f, 0.0f);
//    //argDrawStringsByIdealPos(fps, 20, ysize-30);
//    //argDrawStringsByIdealPos(errValue, 10, ysize-60);
//    //ARLOG("err = %f\n", err);
//
//    //contF2 = 1;
//    //draw(patt_trans);
//    argSwapBuffers();
//}
//
///* cleanup function called when program exits */
//static void cleanup(void)
//{
//    arVideoCapStop();
//    argCleanup();
//	arPattDetach(arHandle);
//	arPattDeleteHandle(arPattHandle);
//	ar3DDeleteHandle(&ar3DHandle);
//	arDeleteHandle(arHandle);
//    arParamLTFree(&gCparamLT);
//    arVideoClose();
//}
//
//static void savetempimage(ARUint8 *mydata) 
//{
//	//This function is used to transfer the captured frame into jpg and save it
//	char myname[20];
//	strcpy(myname, "Cong/image/temp.jpg");
//	if (arVideoSaveImageJPEG(arHandle->xsize, arHandle->ysize, arHandle->arPixelFormat, mydata, myname, 75, 0) < 0) {
//		ARLOGe("Error saving video image.\n");
//		return;
//	}
//}
//
//static void saveimg(int mynumber, int makerid)
//{
//	//In this function, we accutally only change the name of the saved 
//	//temp.jpg. In such a case, we don't have to save the image again.
//	int ret;
//	char myname[50];
//	char tempnum[20];
//	strcpy(myname, "Cong/image/img_");
//	_itoa(makerid, tempnum, 10); //transfer a int number into string. 10 means decimalism
//	strcat(myname, tempnum);
//	strcat(myname, "_");
//	_itoa(mynumber, tempnum, 10); //transfer a int number into string. 10 means decimalism
//	strcat(myname, tempnum);
//	strcat(myname, ".jpg");
//	ret = rename("Cong/image/temp.jpg", myname); //rename the temp.jpg to img_markerid_imgnumber.jpg
//	if (ret == 0)
//	{
//		printf("%s\n", myname);
//	}
//	else
//	{
//		printf("Error: unable to rename the file");
//		return;
//	}
//	
//
//	//double tempnumber[1][2] = {makerid,mynumber};
//
//	//here we put the image number value to matlab
//	//memcpy((void *)mxGetPr(imagename), (void *)tempnumber, sizeof(double) * 1 * 2);
//	//memcpy((char *)mxGetPr(imagename), (char *)tempnumber, 1 * 1 * sizeof(double)); //copy values
//	//engPutVariable(ep, "imagename", imagename);
//	//engEvalString(ep, "imagename = ['c:/dev/ARToolKit5/bin/Cong/image/img_',num2str(imagename(1)),'_',num2str(imagename(2)),'.jpg'];");
//}
//
//static void savetrans(int mynumber, ARdouble trans[3][4], int makerid) {
//	/*About the transformation matrix trans[3][4]
//	If we consider the transformation matrix of individual markers, 
//	the first three columns are a rotation matrix which represent 
//	the rotation of the marker with respect to the origin of the multimarker 
//	set. This is the standard 3�3 rotation matrix familiar in computer graphics 
//	or linear algebra. The fourth column is the offset from the origin 
//	of the multimarker set to the origin (the centre) of this the individual marker.	
//	*/
//
//	int i, j;
//	char myname[50];
//	char tempnum[20];
//	strcpy(myname, "Cong/image/tran_");
//	_itoa(makerid, tempnum, 10); //transfer a int number into string. 10 means decimalism
//	strcat(myname, tempnum);
//	strcat(myname, "_");
//	_itoa(mynumber, tempnum, 10); //transfer a int number into string. 10 means decimalism
//	strcat(myname, tempnum);
//	strcat(myname, ".txt");
//
//	FILE *handlewrite = fopen(myname, "w");
//	for (i = 0; i < 3; i++){
//		for (j = 0; j < 4; j++) {
//			//printf("yangcong------%f  ", trans[i][j]);
//			fprintf(handlewrite, "%f ", trans[i][j]);
//		}
//		fprintf(handlewrite, "\n");
//	}
//
//	fclose(handlewrite);
//}
//
//static void savemaklocation(int mynumber, ARdouble markerinside[4][2], ARdouble markeroutside[4][2], int makerid) {
//	/*In this function, we will save the makers location into file. markerinside[4][2] means the four 
//	vertex inside the black area of marker. markeroutside means the four vertex outside the marker.
//	*/
//
//	int i, j;
//	char myname[50];
//	char tempnum[20];
//	strcpy(myname, "Cong/image/makloca_");
//	_itoa(makerid, tempnum, 10); //transfer a int number into string. 10 means decimalism
//	strcat(myname, tempnum);
//	strcat(myname, "_");
//	_itoa(mynumber, tempnum, 10); //transfer a int number into string. 10 means decimalism
//	strcat(myname, tempnum);
//	strcat(myname, ".txt");
//
//	FILE *handlewrite = fopen(myname, "w");
//	for (i = 0; i < 4; i++){
//		for (j = 0; j < 2; j++) {
//			//printf("yangcong------%f  ", trans[i][j]);
//			fprintf(handlewrite, "%f ", markerinside[i][j]);
//		}
//		fprintf(handlewrite, "\n");
//	}
//	for (i = 0; i < 4; i++){
//		for (j = 0; j < 2; j++) {
//			//printf("yangcong------%f  ", trans[i][j]);
//			fprintf(handlewrite, "%f ", markeroutside[i][j]);
//		}
//		fprintf(handlewrite, "\n");
//	}
//	fclose(handlewrite);
//}
//
////
////static double * viewpointcal(ARdouble trans[3][4]) {
////	/*In this function, we try to calculate the viewpoint from the 
////	transformation matrix trans[3][4]. The output is [x,y,z] About 
////	the transformation matrix trans[3][4]. If we consider the transformation 
////	matrix of individual markers, the first three columns are a rotation matrix 
////	which represent	the rotation of the marker with respect to the origin of 
////	the multimarker set. This is the standard 3�3 rotation matrix familiar 
////	in computer graphics or linear algebra. The fourth column is the offset 
////	from the origin of the multimarker set to the origin (the centre) of this 
////	the individual marker.
////	*/
////	int i, j;
////
////	printf("Product of matrix Original:\n");
////	for (i = 0; i < 3; i++){
////		for (j = 0; j < 4; j++){
////			printf("%f\t", trans[i][j]);
////		}
////		printf("\n");
////	}
////
////
////	int mycountro = 0;
////	int mycounttr = 0;
////	double RoM[3][3], TrM[3];
////	// First step: Generate the rotation matrix and the 
////	for (i = 0; i < 3; i++) {
////		mycountro = 0;
////		for (j = 0; j < 4; j++) {
////			if (j < 3){
////				RoM[i][mycountro] = -1 * trans[i][j];
////				mycountro = mycountro + 1;
////			}
////			else{
////				TrM[mycounttr] = trans[i][j];
////				mycounttr = mycounttr + 1;
////			}
////		}
////	}
////
////	printf("Product of matrix A:\n");
////	for (i = 0; i < 3; i++){
////		for (j = 0; j < 3; j++){
////			printf("%f\t", RoM[i][j]);
////		}
////		printf("\n");
////	}
////
////	printf("Product of matrix B:\n");
////	for (i = 0; i < 3; i++) {
////		printf("%f\t", TrM[i]);
////	}
////	printf("\n");
////
////	double ViewPoint[3];
////	//second step: calculate the viewpoint location by multiplication of two matrix
////	//we need to ensure the column number of matrix A = the row number of matrix B
////	// RoM * TrM: [3][3] * [3][1] = [3, 1]
////
////	//m, n the number of rows and columns of first matrix
////	//p, q the number of rows and columns of second matrix
////	int c, d, k;
////	int m = 3; int n = 3; int p = 3; int q = 1; 
////	double sum = 0;
////	for (c = 0; c < m; c++) {
////		for (d = 0; d < q; d++) {
////			for (k = 0; k < p; k++) {
////				sum = sum + RoM[c][k] * TrM[k];
////			}
////			ViewPoint[c] = sum;
////			sum = 0;
////		}
////	}
////
////	return ViewPoint;
////}
//
//static void get_cpara(ARdouble world[4][2], ARdouble vertex[4][2], ARdouble para[3][3])
//{
//	ARMat   *a, *b, *c;
//	int     i;
//
//	a = arMatrixAlloc(8, 8);
//	b = arMatrixAlloc(8, 1);
//	c = arMatrixAlloc(8, 1);
//	for (i = 0; i < 4; i++) {
//		a->m[i * 16 + 0] = world[i][0];
//		a->m[i * 16 + 1] = world[i][1];
//		a->m[i * 16 + 2] = 1.0;
//		a->m[i * 16 + 3] = 0.0;
//		a->m[i * 16 + 4] = 0.0;
//		a->m[i * 16 + 5] = 0.0;
//		a->m[i * 16 + 6] = -world[i][0] * vertex[i][0];
//		a->m[i * 16 + 7] = -world[i][1] * vertex[i][0];
//		a->m[i * 16 + 8] = 0.0;
//		a->m[i * 16 + 9] = 0.0;
//		a->m[i * 16 + 10] = 0.0;
//		a->m[i * 16 + 11] = world[i][0];
//		a->m[i * 16 + 12] = world[i][1];
//		a->m[i * 16 + 13] = 1.0;
//		a->m[i * 16 + 14] = -world[i][0] * vertex[i][1];
//		a->m[i * 16 + 15] = -world[i][1] * vertex[i][1];
//		b->m[i * 2 + 0] = vertex[i][0];
//		b->m[i * 2 + 1] = vertex[i][1];
//	}
//	arMatrixSelfInv(a);
//	arMatrixMul(c, a, b);
//	for (i = 0; i < 2; i++) {
//		para[i][0] = c->m[i * 3 + 0];
//		para[i][1] = c->m[i * 3 + 1];
//		para[i][2] = c->m[i * 3 + 2];
//	}
//	para[2][0] = c->m[2 * 3 + 0];
//	para[2][1] = c->m[2 * 3 + 1];
//	para[2][2] = 1.0;
//	arMatrixFree(a);
//	arMatrixFree(b);
//	arMatrixFree(c);
//}
//
//static int getPatternVerticesFromMarkerVertices(const ARdouble vertex[4][2], ARdouble patternVertex[4][2])
//{
//	int i;
//	ARdouble    world[4][2];
//	ARdouble    local[4][2];
//	ARdouble    para[3][3];
//	ARdouble    d, xw, yw;
//	ARdouble    pattRatio1, pattRatio2;
//
//	world[0][0] = 100.0;
//	world[0][1] = 100.0;
//	world[1][0] = 100.0 + 10.0;
//	world[1][1] = 100.0;
//	world[2][0] = 100.0 + 10.0;
//	world[2][1] = 100.0 + 10.0;
//	world[3][0] = 100.0;
//	world[3][1] = 100.0 + 10.0;
//	for (i = 0; i < 4; i++) {
//		local[i][0] = vertex[i][0];
//		local[i][1] = vertex[i][1];
//	}
//	get_cpara(world, local, para);
//
//	pattRatio1 = (1.0 - pattRatio) / 2.0 * 10.0; // borderSize * 10.0
//	pattRatio2 = 10.0*pattRatio;
//
//	world[0][0] = 100.0 + pattRatio1;
//	world[0][1] = 100.0 + pattRatio1;
//	world[1][0] = 100.0 + pattRatio1 + pattRatio2;
//	world[1][1] = 100.0 + pattRatio1;
//	world[2][0] = 100.0 + pattRatio1 + pattRatio2;
//	world[2][1] = 100.0 + pattRatio1 + pattRatio2;
//	world[3][0] = 100.0 + pattRatio1;
//	world[3][1] = 100.0 + pattRatio1 + pattRatio2;
//
//	for (i = 0; i < 4; i++) {
//		yw = world[i][1];
//		xw = world[i][0];
//		d = para[2][0] * xw + para[2][1] * yw + para[2][2];
//		if (d == 0) return -1;
//		patternVertex[i][0] = (para[0][0] * xw + para[0][1] * yw + para[0][2]) / d;
//		patternVertex[i][1] = (para[1][0] * xw + para[1][1] * yw + para[1][2]) / d;
//	}
//	return (0);
//}