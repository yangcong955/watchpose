function debugDisp(debug,str)
%%%%%%%%%%%%%%%%%%%%

if (debug)
          disp(str);
end