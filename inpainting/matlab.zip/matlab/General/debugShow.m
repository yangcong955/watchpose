function debugShow(debug,str,val)
%%%%%%%%%%%%%%%%%%%%%%%

if (debug)
          show(str,val);
end