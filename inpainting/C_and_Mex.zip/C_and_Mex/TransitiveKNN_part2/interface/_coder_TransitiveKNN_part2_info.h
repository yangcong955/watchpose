/*
 * _coder_TransitiveKNN_part2_info.h
 *
 * Code generation for function 'TransitiveKNN_part2'
 *
 * C source code generated on: Wed Nov 19 10:38:03 2014
 *
 */

#ifndef ___CODER_TRANSITIVEKNN_PART2_INFO_H__
#define ___CODER_TRANSITIVEKNN_PART2_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* End of code generation (_coder_TransitiveKNN_part2_info.h) */
